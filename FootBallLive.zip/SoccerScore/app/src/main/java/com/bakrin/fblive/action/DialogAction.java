package com.bakrin.fblive.action;

public enum DialogAction {
    OK,CANCEL
}
