package com.bakrin.fblive.action;

/**
 * Created by ayesh on 8/29/17.
 */

public enum ActionbarMenu {

    BACK,FIXTURE,FIXTURE_LAYOUT,SEARCH,DRAWER
}
