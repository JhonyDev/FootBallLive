package com.bakrin.fblive.listener;


import com.bakrin.fblive.action.DialogAction;

public interface DialogActionListener {

    public void onDialogAction(DialogAction action);
}
