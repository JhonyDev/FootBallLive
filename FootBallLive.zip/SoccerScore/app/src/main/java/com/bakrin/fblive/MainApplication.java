package com.bakrin.fblive;

import android.app.Application;

import com.bakrin.fblive.api.APIManager;


public class MainApplication extends Application {

    private static MainApplication instance;
    private APIManager apiManager;

    public static MainApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        instance = this;
        apiManager = APIManager.getInstance(this);


    }

    public APIManager getApiManager() {
        return apiManager;
    }
}
