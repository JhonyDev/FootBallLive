package com.bakrin.fblive.listener;

import com.bakrin.fblive.model.response.PointTableItem;

public interface PointTableItemSelectListener {

    public void onPointTableItemSelect(int pos, PointTableItem pointTableItem);
}
