package com.bakrin.fblive.listener;

import com.bakrin.fblive.model.response.TopScorerItem;

public interface TopScorerSelectListener {

    public void onTopScorerSelect(int pos , TopScorerItem topScorerItem);
}
