package com.bakrin.fblive.action;

public enum DialogType {

    ERROR,INFO,SUCCESS
}
