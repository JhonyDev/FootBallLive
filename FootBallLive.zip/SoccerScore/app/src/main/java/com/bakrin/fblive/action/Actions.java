package com.bakrin.fblive.action;

public enum Actions {
    VIEW,VIEW_LEAGUE,DELETE,REFRESH,LIST_REFRESH,CHANGE
}
