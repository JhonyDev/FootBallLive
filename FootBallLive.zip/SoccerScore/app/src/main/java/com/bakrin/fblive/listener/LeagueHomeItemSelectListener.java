package com.bakrin.fblive.listener;

import com.bakrin.fblive.model.response.LeagueListItem;

public interface LeagueHomeItemSelectListener {

    public void onHomeLeagueItemSelect(int pos, LeagueListItem leagueListItem);
}
